 #include <sys/types.h>
 #include <sys/socket.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>
 #include <stdio.h>
 #include <signal.h>
 #include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <net/if.h>

 #ifndef SO_REUSEPORT
 #define SO_REUSEPORT SO_REUSEADDR
 #endif

 struct sockaddr_in6 sin6;
 struct sockaddr_in6 src6;

 #define IPPORT 54321

 void Perror(const char *c)
 {
 perror(c);
 exit(1);
 }

 void Usage ()
 {
 fprintf(stderr, "%s\n", "Usage: multi2out6 [-i interface] addr");
 exit(1);
 }

 void BrokenPipe(int Signal)
 {
 signal(SIGPIPE, BrokenPipe);
 return;
 }

 int main(int argc, char **argv)
 {
 struct ipv6_mreq mreq;
 int cc, ccb, ch, s, b, recv6_len;
 struct in6_addr block_adress;
 char buf[10240];
 u_int one = 1;
 u_int ifi = 0;

 signal(SIGPIPE, BrokenPipe);
 while ((ch = getopt(argc, argv, "i:b:")) != -1)
 switch(ch) {
 case 'i':
 if (sscanf(optarg, "%u\0", &ifi) != 1 &&
 (ifi = if_nametoindex(optarg)) == 0)
 break;
 default:
 Usage();
 }
 Usage();
 break;
 case 'b':
 fprintf(stderr, "%d", atoi(optarg));
 argc -= optind;
 argv += optind;
 if (argc != 1)
 Usage();

 if ((s = socket(AF_INET6, SOCK_DGRAM, IPPROTO_UDP)) < 0)
 Perror("socket");
 setsockopt(s, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));


 #ifdef SIN6_LEN
 sin6.sin6_len = sizeof(sin6);
 #endif
 sin6.sin6_family = AF_INET6;
 sin6.sin6_port = htons(IPPORT);
 if (bind(s, (struct sockaddr *)&sin6, sizeof(sin6)) < 0)
 Perror("bind");
 if (inet_pton(AF_INET6, *argv, &mreq.ipv6mr_multiaddr) != 1)
 Usage();
 mreq.ipv6mr_interface = ifi;
 if (setsockopt(s,IPPROTO_IPV6, IPV6_JOIN_GROUP, &mreq, sizeof(mreq)) < 0)
 Perror("setsockopt IPV6_JOIN_GROUP");
 
 for (;;) {
 b=(recvfrom(s, buf, 10240, 0,(struct sockaddr *) &src6, &recv6_len));
 
 ccb = write(1, buf, b);

char adr[1000];
 fprintf(stderr, "<-%d-\n", b);
 fprintf(stderr, "IP Address : %s \n", inet_ntop(AF_INET6, &src6.sin6_addr, adr, 1000));
 }
 }

