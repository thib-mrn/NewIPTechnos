package Netbrans.RecieveMulticast.*;
import java.*;

public class multicastReception {
    public static void main(String[] args) throws IOException {
        int port = 54321; //comme définit dans in2multi6
        MulticastSocket socket = new MulticastSocket(port);
        InetAddress AddrGrp = Inet6Address.getByName("ff12::3000");//adresse du groupe que l'on a décidé auparavant
        socket.joinGroup(AddrGrp);
        byte[] temp = new byte[1500];
        DatagramPacket recv = new DatagramPacket(temp, temp.length);
        boolean test = true;
        while(test) {
            socket.receive(recv);
            String msg = new String(temp);
            System.out.println(msg);
            if (msg.equals("STOP")) {
                test = false;
            }
        }
        socket.close();
    }
}