package Netbrans.sendMulticast.*;
import java.*;

public class multicastEnvoie {
    public static void main(String[] args) throws IOException {
        int port = 54322; //comme défini dans multi2out6
        MulticastSocket socket = new MulticastSocket(port);
        InetAddress groupAddress = Inet6Address.getByName("ff12::3000");//adresse du groupe que l'on a décidé auparavant
        socket.joinGroup(groupAddress);
        Scanner scanner = new Scanner(System.in);
        String msgSend;
        while((msgSend = scanner.nextLine()) != null && !line.equals("!stop")) {
            msgSend = line + "\n";
            DatagramPacket msg = new DatagramPacket(line.getBytes(), line.length(), groupAddress, 54321);
            socket.send(msg);
        }
        socket.close();
    }
}